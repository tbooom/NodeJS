module.exports = function(application)
{
    application.get('/', function(req, res)
    {
        console.log('Consultou a view index Method: get'); 
        application.app.controllers.index.indexController(application, req, res);
               
    });






} 