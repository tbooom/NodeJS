module.exports = function(application)
{
    application.post('/chat', function(req, res)
    {
        console.log('Consultou a view chat Method: post');
        application.app.controllers.chat.chatController(application, req, res);
        
    });

    application.get('/chat', function(req, res)
    {
        console.log('Consultou a view chat Method: get');
        application.app.controllers.chat.chatController(application, req, res);
        
    });


}   