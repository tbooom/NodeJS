module.exports.indexController = function(application, req, res)
{
    console.log('Chegou na controller index');
    res.render('index', {validacao:{}});
    console.log('a indexController renderizou a view index\n- - - - - - - - - ');
}