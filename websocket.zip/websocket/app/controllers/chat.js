module.exports.chatController = function(application, req, res)
{
    var dadosForm = req.body;
    console.log('Variavel: ', dadosForm)
    req.assert('apelido', 'Nome ou apelido é obrigatório.').notEmpty();
    req.assert('apelido', 'O nome ou apelido deve conter entre 3 e 30 caracteres.').len(3, 30);
    
    var errors = req.validationErrors();
    
    if(errors)
    {
        res.render('index', {validacao : errors})
        return;
    }
    
    console.log('Chegou na controller chat');
    res.render('chat');
    console.log('A controller chatController renderizou a view chat\n- - - - - - - - - -');
}